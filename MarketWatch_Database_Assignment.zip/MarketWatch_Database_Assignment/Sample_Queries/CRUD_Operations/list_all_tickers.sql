SELECT ticker_symbol, company_name, sector, industry
FROM Ticker
ORDER BY ticker_symbol;
