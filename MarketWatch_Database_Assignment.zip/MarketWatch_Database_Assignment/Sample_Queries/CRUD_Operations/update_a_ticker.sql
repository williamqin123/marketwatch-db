UPDATE Ticker
SET sector = 'Energy'
WHERE ticker_symbol = 'TEST';
