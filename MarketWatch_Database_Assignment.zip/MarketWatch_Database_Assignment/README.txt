MarketWatch Database Assignment
================================

This submission package contains:

1. DATABASE_DOCUMENTATION.md
   - Complete technical documentation
   - Detailed explanation of trigger and stored procedure
   - Database schema overview
   - Use cases and examples

2. SQL_Scripts/
   - create_tables.sql: Creates all database tables
   - insert_sample_data.generated.sql: Populates tables with sample data

3. Trigger/
   - create_holdings_trigger.sql: Audit log trigger for Holdings table

4. Stored_Procedure/
   - get_user_portfolio_details.sql: Retrieve complete portfolio information

5. Sample_Queries/
   - CRUD_Operations/ (4 queries)
     * CREATE, READ, UPDATE, DELETE examples
   - JOIN_Operations/ (3 queries)
     * Multi-table joins, subqueries, LEFT JOIN with aggregation
   - Aggregate_Functions/ (3 queries)
     * AVG, COUNT, SUM with GROUP BY

Total: 15 files demonstrating comprehensive SQL knowledge

How to Use:
-----------
1. Run create_tables.sql to create the database schema
2. Run insert_sample_data.generated.sql to populate with sample data
3. Run create_holdings_trigger.sql to set up the audit trigger
4. Run get_user_portfolio_details.sql to create the stored procedure
5. Execute any sample queries to see the database in action

For detailed information, please refer to DATABASE_DOCUMENTATION.md
